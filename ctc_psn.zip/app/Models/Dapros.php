<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dapros extends Model
{
    use HasFactory;
    protected $table = 'daproses';
    protected $fillable = ['periode',    'type',    'ofi_awal',    'kat_hvc',    'kat_pembayaran',    'los cust',    'rev_arpu', 'avg_redaman',    'datel', 'jml_device', 'nama',    'nd',    'no_hp', 'product_type',    'sto',    'usage_inet',    'tgl_upload_data',    'tgl_dispatch',    'agent_id',    'tanggal_visit',    'ofi_real_id', '	afi_id',    'foto_rumah',    'yg_ditemui',    'status_tmpt_tinggal',    'kemampuan_cust',    'keterangan_bayar',    'retensi',    'tagging_lokasi', 'kompetitor',    'status'];
}
